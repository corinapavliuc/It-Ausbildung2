package scanner;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Уважаемый пользователь, перед вами программа - складыватель. Следуйте инструкциям:");
        System.out.print("Введите первое число: ");
        int firstNumber = scanner.nextInt();

        System.out.println();
        System.out.print("Введите второе число: ");
        int secondNumber = scanner.nextInt();

        System.out.println();

        int result = firstNumber + secondNumber;

        System.out.println("Результат сложения введенных вами чисел равен: ");
        System.out.println(firstNumber + secondNumber);
        System.out.println("___________________________");
        System.out.println(result);
    }
}
