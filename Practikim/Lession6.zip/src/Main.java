import animals.Cat;

public class Main {

    public static void main(String[] args) {
        System.out.println("Старт программы");

        Cat firstCat = new Cat("Мурка"); // где-то под капотом java создается объект по этому конструктору.
        // где-то там под капотом java этот объект присваивается переменной firstCat

        firstCat.meow();

        Cat secondCat = new Cat("Снежок");

        secondCat.meow();

        System.out.println("Конец программы");
    }
}
