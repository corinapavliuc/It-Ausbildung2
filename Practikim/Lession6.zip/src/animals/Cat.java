package animals;

public class Cat {

    public String name;

    public Cat(String name) {
        this.name = name;
    }

    public void meow() {
        System.out.print("Мяу! ");
        System.out.println("Я прекрасная кошка, меня зовут: " + name);
    }
}
