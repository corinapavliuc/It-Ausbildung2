package methods;

public class DefaultCaller {

    public static void callDefaultMethodFromCalculator() {
        System.out.println("DefaultCaller class: callDefaultMethodFromCalculator started");
        Calculator.defaultMethod();
        System.out.println("DefaultCaller class: callDefaultMethodFromCalculator ended");
    }
}
