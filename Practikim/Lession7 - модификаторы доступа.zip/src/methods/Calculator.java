package methods;

public class Calculator {

    private static void privateMethod() {
        System.out.println("Calculator class: I'm a private method");
    }

    public static void callPrivateMethod() {
        System.out.println("Calculator class: callPrivateMethod started");
        privateMethod();
        System.out.println("Calculator class: callPrivateMethod ended");
    }

    static void defaultMethod() { // модификатор доступа default не пишется. Он задается неявно, когда мы не пишем никаких модификаторов
        System.out.println("Calculator class: I'm a default method");
    }
}
