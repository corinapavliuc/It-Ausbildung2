import field.FieldExampleClass;
import field.StaticFieldExampleClass;

public class Main {

    public static void main(String[] args) {
        String title = "Hello world!";

        System.out.println(title); // это пример того, как переменная title ВИДНА внутри метода main

        FieldExampleClass fieldExampleClass = new FieldExampleClass();

        System.out.println(fieldExampleClass.count); // здесь я просто отобразил значение переменной count внутри объекта
        fieldExampleClass.count = 50; // здесь я этой переменной присвоил новое значение
        System.out.println(fieldExampleClass.count); // здесь я отобразил новое значение

        FieldExampleClass anotherFieldExampleClass = new FieldExampleClass(); // это НОВЫЙ объект
        System.out.println(anotherFieldExampleClass.count); // это переменная count НОВОГО объекта

        System.out.println("________________________________________________________");

        fieldExampleClass.expression = "I was changed"; // меняю переменную для объекта fieldExampleClass

        System.out.println(fieldExampleClass.expression); // вывожу переменную объекта fieldExampleClass (значение изменилось)

        System.out.println(anotherFieldExampleClass.expression); // вывожу переменную объекта anotherFieldExampleClass (значение не изменилось)

        System.out.println("________________________________________________________");

        System.out.println(StaticFieldExampleClass.staticExpression); // вывожу значение статической переменной класса StaticFieldExampleClass

        StaticFieldExampleClass.staticExpression = "I'm a static and I was changed"; // меняю это значение

        System.out.println(StaticFieldExampleClass.staticExpression); // вывожу еще раз эту переменную - значение изменилось

    }

    public static void invisibleVariableExample() {
//        System.out.println(title); это пример того, как метод invisibleVariableExample НЕ ВИДИТ переменную title в методе main
    }
}
