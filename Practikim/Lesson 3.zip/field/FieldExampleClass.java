package field;

public class FieldExampleClass {

    public int count = 0;
    public String expression = "Hello everybody I'm new one!";
}
