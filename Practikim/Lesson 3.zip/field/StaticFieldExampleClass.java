package field;

public class StaticFieldExampleClass {

    public static String staticExpression = "Hello everyone! I'm static new one";
}
