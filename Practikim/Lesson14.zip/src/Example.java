public class Example {

    public static void main(String[] args) {
//        while (true) {
//            System.out.println("Hello, world!");
//
//            break;
//        }

        do {
            System.out.println("Hello, world!");
        } while (false);
    }
}
