import loop.Counter;

public class Main {

    public static void main(String[] args) {

        Counter firstCounter = new Counter("firstCounter","Привет, я первый каунтер");

        firstCounter.count(1);
        firstCounter.printName();

        System.out.println("__________________________________________________");

        Counter secondCounter = new Counter("secondCounter","Привет, я второй каунтер");

        secondCounter.count(1);
        secondCounter.printName();

        System.out.println("__________________________________________________");

        Counter anotherRemoteControllerOfFirstCounter = firstCounter;

        anotherRemoteControllerOfFirstCounter.count(1);
        anotherRemoteControllerOfFirstCounter.printName();

        System.out.println("__________________________________________________");

        anotherRemoteControllerOfFirstCounter.name = "Имя было изменено";

        firstCounter.printName();
    }
}
