package task;

public class Test {

    public String testCase = "Simple test case";
}
